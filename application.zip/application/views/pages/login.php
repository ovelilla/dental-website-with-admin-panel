<section class="section page-header">
    <div class="container">
        <h1>Acceso area privada</h1>
    </div>
</section>

<section class="section login">
    <div class="container" id="login">
    </div>
</section>