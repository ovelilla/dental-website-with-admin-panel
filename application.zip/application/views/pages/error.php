<section class="section header-margin">
    <div class="container">
        <div class="error404">
            <div class="code">404</div>
            <div class="title">Página no encontrada</div>
            <div class="message">Lo sentimos, la página que estás buscando no existe.</div>
            <a class="btn primary-btn" href="/">Volver a la página principal</a>
        </div>
    </div>
</section>